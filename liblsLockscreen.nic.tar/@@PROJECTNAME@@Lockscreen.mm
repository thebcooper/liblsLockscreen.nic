#import "LibLockscreen.h"
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <objc/runtime.h>

static LibLSController *controller;

@interface @@PROJECTNAME@@Lockscreen : UIView <LibLockscreen>{
  UILabel *timeLabel;
}
-(UIView *)initWithFrame:(CGRect)frame; //Required
-(float)liblsVersion; //Required
-(void)updateClock;
-(void)receivedNotification:(NSMutableDictionary *)notification;
-(void)unlock;
@end



@implementation @@PROJECTNAME@@Lockscreen

-(UIView *)initWithFrame:(CGRect)frame{
	self = [super initWithFrame:frame];
    if (self){
		controller = [objc_getClass("SBAwayController") sharedLibLSController]; //With this, we can use methods from the tweak that could be useful.
		self.backgroundColor = [UIColor colorWithPatternImage:[controller backgroundImage]]; //Like this! Just a simple thing to set the background image.

   		timeLabel = [[UILabel alloc] initWithFrame:CGRectMake(0,20,320,100)];
  		timeLabel.textAlignment = UITextAlignmentCenter;
  		timeLabel.font = [UIFont fontWithName:@"Arial-BoldMT" size:68];
  		timeLabel.textColor = [UIColor whiteColor];
  		timeLabel.backgroundColor = [UIColor clearColor];
  		[self updateClock];
  		[self addSubview:timeLabel];
  		[timeLabel release];

 UIButton *button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
[button addTarget:self 
           action:@selector(unlock)
 forControlEvents:UIControlEventTouchDown];
[button setTitle:@"Unlock" forState:UIControlStateNormal];
button.frame = CGRectMake(0,440, 320, 40);
[self addSubview:button];
	}
    return self;
}


-(float)liblsVersion{
	return 0.1; //What version of liblockscreen you built this using, so that legacy support can be provided and things don't break.
}

-(void)updateClock{
NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init]; //ugly. yeah.
NSDate *date = [NSDate date];
  
NSDateFormatter *dateFormatter = [[[NSDateFormatter alloc] init]  autorelease];
[dateFormatter setDateFormat:@"hh:mm"];
  
timeLabel.text = [dateFormatter stringFromDate:date];

[pool drain]; //Look, just a template. I will change it eventually.
}

-(void)unlock{
  [controller unlock];  //Simple enough, right?
}

-(void)receivedNotification:(NSMutableDictionary *)notification{
/*
------Notifications--------
So, this makes handling notifications hopefully a bit easier.
You will get a NSMutableDictionary (don't worry about that, it's incase you need to add more info to it) whenever a notification is released.
It has the following keys:
title -- this is the title of the notification, sometimes the name of the person, or the name of the app depending on the notification.
message -- the body of the notification. If there is no body, it will be NULL (so check for that maybe?)
subtitle -- sometimes notifications have this, sometimes they don't. Do a simple check for if it is there or not and if you should use it.
bundleID -- the identifier of the app, such as com.apple.mobilesms or so on. 
appName -- the display name of the app, which could be Twitter, Messages, Facebook, etc.
originalAlert -- this is the original BBBuletin item of the alert, in case you need to pull more data from it. 
*/


UIAlertView *alert =
[[UIAlertView alloc] initWithTitle: @"@@PROJECTNAME@@ notification"
                     message: [NSString stringWithFormat:@"%@ - %@", [notification objectForKey:@"appName"], [notification objectForKey:@"message"]]
                     delegate: nil
                     cancelButtonTitle: @"OK"
                     otherButtonTitles: nil];
[alert show];
[alert release];
}

@end